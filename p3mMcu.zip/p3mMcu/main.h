#ifndef MAIN_H
#define	MAIN_H


#define _XTAL_FREQ 32000000 
 
 
#endif	/* MAIN_H */

