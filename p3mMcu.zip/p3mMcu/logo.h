
#ifndef LOGOTABLE_H
#define	LOGOTABLE_H

#include <stdint.h>
#include "util.h"

void initLogo();
void logoShowLogo();

#endif	/* LOGOTABLE_H */

